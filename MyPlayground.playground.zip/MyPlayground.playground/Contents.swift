import UIKit
//let makes it a constant
//var makes it a varibale so that it can change
let no = "no"
//set name to an integer
var name: Int
//set name to 13
var list = ["one", "two", "three"]
name = 13
print ("apple \(name)")
//increments i by 1 so it loops 5 times but i increase by 1 each time
for i in 1...5{
    print (i*10)
}
//goes through the list
for i in 0...2{
    print (list[i])
}
//switch and case are pretty much just special if statements
//defualt is like else. if none of the cases work it does defualt
var banana = 5
switch banana {
case 1:
    print ("case one")
case 2:
    print ("case two")
case 3:
    print ("case three")
case 4...6:
    print ("case four")
default:
    print ("default case")
}
//functions use func item(){. call with something like item()
func item(){
    print ("function")
}
item()
//functions can accept variable/info
func thing(name: String, year: Int){
    print ("thing \(name) is in \(year)")
}
//variables inside the function dont even need to be declared
thing(name: "object", year: 2020)
//returns
// -> converts the string to a boolean
func function(name: String) -> Bool{
    if name == "one"{ return true }
    if name == "two"{ return false }
    return false
}
//output based on the input of the thing
if function(name: "two"){
    print ("one")
}else{
    print ("false")
}
