import UIKit
var name: Int
name = 13
print ("apple \(name)")
